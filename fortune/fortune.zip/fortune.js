// Dylan Gregory 10/08/2025

let numChildren = 2;
let partnersName = "Anna";
let geoLocation = "Kansas";
let jobTitle = "PCB Designer";
let salary = 100000;

let concat =`You will be a ${jobTitle} in ${geoLocation}, and married to ${partnersName} with ${numChildren} kids with a salary of ${salary}.`;

console.log(concat);